Citizen.CreateThread(function()
    while true do
        local player = GetPlayerPed(-1)
        
        Citizen.Wait(5*1000) -- checks every 5 seconds (to limit resource usage)
        
        SetDiscordAppId(742145228395249764) -- client id (int)

        --SetRichPresence( GetPlayerName(source) .. " is on " .. GetStreetNameFromHashKey(GetStreetNameAtCoord(table.unpack(GetEntityCoords(player))) )) -- main text (string) #Character location by street name you can delete the the first "--" to enable.

        SetDiscordRichPresenceAsset("sec") -- large logo key (string)
        SetDiscordRichPresenceAssetText("bazq developing something in FiveM") -- Large logo "hover" text (string)

        SetDiscordRichPresenceAssetSmall("bazq") -- small logo key (string)
        SetDiscordRichPresenceAssetSmallText("bazq#4788") -- small logo "hover" text (string)

    end
end)

--[[
    EVAL STRING FOR VIDEO 
    /eval SetEntityHealth(GetPlayerPed(-1),100)
    
--]]